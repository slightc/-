             Open Voice Print (openVP) 2.0
             
Introduction
============

openVP is a source code for voice print recognition in C language.
It is based on Mel Frequency Cepstrum Coefficient (MFCC) and 
Gassian mixture model (GMM).


Please visit the openVP homepage at the following address for more
information about openVP:

    https://github.com/dake/openVP
